﻿# Compilación en Overleaf

1. Suba este ZIP como proyecto nuevo en Overleaf.
2. Seleccione `manual_usuario.tex` como documento principal.
3. Seleccione LuaLaTeX como compilador.
4. Compile el proyecto.
5. No active `shell-escape`.
6. Los metadatos editables están en `configuracion/metadatos.tex` y `configuracion/comandos.tex`.
7. Los capítulos están en `capitulos/`, los anexos en `anexos/` y las capturas usadas en `capturas/finales/`.
8. Los pendientes institucionales editables están descritos en la introducción y en los capítulos donde aparece el marcador correspondiente.

Este paquete no incluye scripts, bases de datos, entorno demo, capturas de prueba ni archivos temporales de compilación.
